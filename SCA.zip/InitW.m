function W=InitW()
rng(100);
Chi=InitC();
K=Chi.K;
Nr=Chi.Nr;
Nt=Chi.Nt;
T=Chi.T;
Sr=Chi.Sr;
Si=Chi.Si;
alphaR=Chi.alphaR;
alphaI=Chi.alphaI;
cR=Chi.cR;
cI=Chi.cI;
Index_cR=Chi.Index_cR;
Index_cI=Chi.Index_cI;
Index_aR=Chi.Index_aR;
Index_aI=Chi.Index_aI;
HtR=Chi.HtR;
HtI=Chi.HtI;
G0R=zeros(K,Nt);
G0I=zeros(K,Nt);
w0R=randn(Nr,K);
w0I=randn(Nr,K);
for k=1:K
        G0R(k,:)=[w0R(:,k)',w0I(:,k)']*[HtR(:,:,k);HtI(:,:,k)];
        G0I(k,:)=[w0R(:,k)',w0I(:,k)']*[HtI(:,:,k);HtR(:,:,k)] ;      
end
cvx_begin quiet
    variable d(K,1) nonnegative;
    variable uR(K,T);
    variable uI(K,T);
    variable wR(Nr,K);
    variable wI(Nr,K);
    variable x(T,1)
    expression GR(K,Nt);
    expression GI(K,Nt);
    expression Rr(K,K);
    expression Ri(K,K);
    expression D(K,T);
    min sum(x)
    subject to
            for k=1:K
                GR(k,:)=[wR(:,k)',wI(:,k)']*[HtR(:,:,k);HtI(:,:,k)];
                GI(k,:)=[wR(:,k)',wI(:,k)']*[HtI(:,:,k);HtR(:,:,k)];
                sum_square_abs(wR(:,k))+sum_square_abs(wI(:,k))<=1;
            end
            D=d*ones(1,T);
            Rr=[GR,GI]*[G0R';-G0I']+[G0R,G0I]*[GR';-GI']+[G0R,G0I]*[G0R';-G0I'];
            Ri=[GR,GI]*[G0I';G0R']+[G0R,G0I]*[GI';GR']+[G0R,G0I]*[G0I';G0R'];
            -D(Index_aR)+alphaR(Index_aR)<=uR(Index_aR);
            uR(Index_cR)<=D(Index_cR)-cR(Index_cR);
            -D(Index_aI)+alphaI(Index_aI)<=uI(Index_aI);
            uI(Index_cI)<=D(Index_cI)-cI(Index_cI);
            for t=1:T    
                   [x(t),(diag(d)*Sr(:,t)+uR(:,t))';diag(d)*Sr(:,t)+uR(:,t),Rr]==semidefinite(K+1);
                   [x(t),(diag(d)*Si(:,t)+uI(:,t))';diag(d)*Si(:,t)+uI(:,t),Ri]==semidefinite(K+1);
            end
 cvx_end
 if strcmp(cvx_status,'Solved') || strcmp(cvx_status,'Inaccurate/Solved')
     W.w0R=wR;
     W.w0I=wI;
 end

               
               
        
