function FinVal=SCATt()
Ttuple=SCAInit();
[Ttuplen,flag]=SCA(Ttuple);
for i=1:10
    if ~flag
        Ttuple=Ttuplen;
        [Ttuplen,flag]=SCA(Ttuple);
    else 
        break;
    end
end
FinVal=Ttuplen;
    



