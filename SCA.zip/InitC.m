function Chi=InitC()
rng(100);
K=4;
Nr=4;
Nt=8;
T=10;
M=16;
% transignal_S:
S=qammod(randi(16,K,T)-1,16);
% S1=[real(S);imag(S)];
% S1=zeros(K,T,L);
Sr=real(S);
Si=imag(S);
% alpha and c
alphaR=zeros(K,T);
alphaI=zeros(K,T);
cR=zeros(K,T);
cI=zeros(K,T);
alphaR=1/sqrt(2)*qfuncinv(0.01/2);
alphaI=1/sqrt(2)*qfuncinv(0.01/2);
cR=1/sqrt(2)*qfuncinv(0.01/2);
cI=1/sqrt(2)*qfuncinv(0.01/2);
alphaR(Sr==sqrt(M)-1)=1/sqrt(2)*qfuncinv(0.01);
alphaR(Sr==-sqrt(M)+1)=-inf;
alphaI(Si==sqrt(M)-1)=1/sqrt(2)*qfuncinv(0.01);
alphaI(Si==-sqrt(M)+1)=-inf;
cR(Sr==-sqrt(M)+1)=-inf;
cR(Sr==-sqrt(M)+1)=1/sqrt(2)*qfuncinv(0.01);
cI(Si==-sqrt(M)+1)=-inf;
cI(Si==-sqrt(M)+1)=1/sqrt(2)*qfuncinv(0.01);
Index_aR=find(~isinf(alphaR));
Index_aI=find(~isinf(alphaI));
Index_cR=find(~isinf(cR));
Index_cI=find(~isinf(cI));
% channel
Ht=zeros(Nr,Nt,K);
for k=1:K
    Ht(:,:,k)=randn(Nr,Nt)+1i*randn(Nr,Nt);
end
HtR=real(Ht);
HtI=imag(Ht);
Chi.K=K;
Chi.Nr=Nr;
Chi.Nt=Nt;
Chi.T=T;
Chi.M=M;
Chi.Sr=Sr;
Chi.Si=Si;
Chi.alphaR=alphaR;
Chi.alphaI=alphaI;
Chi.cR=cR;
Chi.cI=cI;
Chi.Index_cR=Index_cR;
Chi.Index_cI=Index_cI;
Chi.Index_aR=Index_aR;
Chi.Index_aI=Index_aI;
Chi.HtR=HtR;
Chi.HtI=HtI;

